<?php

namespace thiagoalessio\TesseractOCR;

class UnsuccessfulCommandException extends TesseractOcrException
{
}
